import java.util.Scanner;

public class arithmetic
{
	// main method begins execution of Java application
	   public static void main(String[] args)
	   {
	      // create a Scanner to obtain input from the command window
	      Scanner input = new Scanner(System.in);

	      int number1; // first number to add
	      int number2; // second number to add
	      int sum; // sum of number1 and number2
	      int product; //product of number1 and number 2
	      int difference; //difference of number1 and number2
	      int division; //division of number1 and number2

	      System.out.print("Enter first integer: "); // prompt 
	      number1 = input.nextInt(); // read first number from user

	      System.out.print("Enter second integer: "); // prompt 
	      number2 = input.nextInt(); // read second number from user

	      sum = number1 + number2; // add numbers, then store total in sum
	      product = number1*number2; //multiplies numbers, then stores total in product
	      difference = number1 - number2; //subtracts numbers, then stores total in difference
	      division = number1/number2; //divides numbers, then stores total in division
	      
	      System.out.printf("Sum is %d%n", sum); // display sum
	      System.out.printf("Product is %d%n", product); //display product
	      System.out.printf("Difference is %d%n", difference); //display difference
	      System.out.printf("Division is %d%n", division); //display division
	   } // end method main
}
